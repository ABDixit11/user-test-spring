package com.example.demo.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="userdata", schema="public")
public class User {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "userid")
	private int user_id;
	@Column(name="email")
	private String email;
	@Column(name="pword")
	private String pword;
	@Column(name="firstname")
	private String firstname;
	@Column(name="lastname")
	private String lastname;
	@Column(name="department")
	private String department;
	@Column(name="gender")
	private String gender;
	
	public User(int user_id, String email, String pword, String firstname, String lastname, String department,
			String gender) {
		super();
		this.user_id = user_id;
		this.email = email;
		this.pword = pword;
		this.firstname = firstname;
		this.lastname = lastname;
		this.department = department;
		this.gender = gender;
	}

		public User() {
		// TODO Auto-generated constructor stub
	}
		

		public User(String email, String pword, String firstname, String lastname, String department, String gender) {
			super();
			this.email = email;
			this.pword = pword;
			this.firstname = firstname;
			this.lastname = lastname;
			this.department = department;
			this.gender = gender;
		}

		public int getUser_id() {
			return user_id;
		}

		public void setUser_id(int user_id) {
			this.user_id = user_id;
		}

		public String getEmail() {
			return email;
		}

		public void setEmail(String email) {
			this.email = email;
		}

		public String getPword() {
			return pword;
		}

		public void setPword(String pword) {
			this.pword = pword;
		}

		public String getFirstname() {
			return firstname;
		}

		public void setFirstname(String firstname) {
			this.firstname = firstname;
		}

		public String getLastname() {
			return lastname;
		}

		public void setLastname(String lastname) {
			this.lastname = lastname;
		}

		public String getDepartment() {
			return department;
		}

		public void setDepartment(String department) {
			this.department = department;
		}

		public String getGender() {
			return gender;
		}

		public void setGender(String gender) {
			this.gender = gender;
		}

		@Override
		public String toString() {
			return "User [user_id=" + user_id + ", email=" + email + ", pword=" + pword + ", firstname=" + firstname
					+ ", lastname=" + lastname + ", department=" + department + ", gender=" + gender + "]";
		}


}
