package com.example.demo.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.entity.User;
import com.example.demo.repository.UserRepository;

@RestController
public class UserController {
	
	@Autowired
	UserRepository repo;
	
	@GetMapping("/manualcreate")
	@ResponseBody
	public String manualCreate() {
		
		repo.save(new User("abhi@78945.com","12345","Abhi","Dix","I&P","Male"));
		return "Object Created";
		
	}
	
	@GetMapping(path="/allusers")
	public List<User> addUser()
	{
		return repo.findAll();
	} 
}
